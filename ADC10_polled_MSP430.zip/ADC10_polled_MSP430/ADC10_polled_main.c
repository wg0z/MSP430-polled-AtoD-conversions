/*
 * ADC10_polled_main.c
 *    this very simple program shows how to do a/d conversions without interrupts;
 *    ADC10IFG is used as a conversion complete flag
 */



#include <msp430.h>				

/*
 * CHNL_NUM should be in the range allowed by the specific device
 * for 'G2553, A1 is P0.1 and is pin 3 of the MCU
 */

#define CHNL_NUM 1


unsigned conversionResult;

void main(void)
{
	WDTCTL = WDTPW | WDTHOLD;		// stop watchdog timer

    ADC10CTL0 = ADC10SHT_2 + ADC10ON;   // set 16 clks/conversion and ADC10ON, ENC will be 0
    ADC10AE0 |= (1 << CHNL_NUM);        // set pin specified by CHNL_NUM for ADC operation
    ADC10CTL1 =  CHNL_NUM * INCH_1;     // set adc10ctl1 register for specified channel

	for(;;)
	{
	    ADC10CTL0 |= ENC + ADC10SC;             // Sampling and conversion start
	    while ( 0 == (ADC10CTL0 & ADC10IFG));   // wait for IFG bit to go to 1
	    ADC10CTL0 &= ~(ADC10IFG | ENC);         // manually reset IFG and ENC, ADC10SC bit will auto-reset
        conversionResult = ADC10MEM;            // read conversion result

	} // end for(ever)

} // end main()
